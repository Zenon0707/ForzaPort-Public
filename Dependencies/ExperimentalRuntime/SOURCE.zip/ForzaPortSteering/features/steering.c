/* Generic, opt-in source suspension limits. No fixture IDs or guessed rear steer. */
#include "features.h"
#include "support.h"
#include "logging.h"
#include "steering_policy.h"
typedef struct { char storage[16]; size_t length,capacity; } FpString;
typedef struct { void *address,*definition; FpSteering selection; int valid; } FpObject;
static unsigned char *image;
static FpSteering rows[4096];
static unsigned row_count,next_definition,next_object;
static FpObject definitions[64],objects[64];
static SRWLOCK lock=SRWLOCK_INIT;
static INIT_ONCE profiles_once=INIT_ONCE_STATIC_INIT;
static int append_path(wchar_t *dst,unsigned cap,const wchar_t *suffix) {
 unsigned n=0;while(n<cap&&dst[n])n++;while(*suffix){if(n+1>=cap)return 0;dst[n++]=*suffix++;}dst[n]=0;return 1;
}
static void load_profiles(void) {
 static wchar_t root[1024],pattern[1024];
 DWORD n=GetModuleFileNameW(NULL,root,ARRAY_COUNT(root));if(!n||n>=ARRAY_COUNT(root))return;
 while(n&&root[n-1]!=L'\\'&&root[n-1]!=L'/')n--;root[n]=0;
 if(!append_path(root,ARRAY_COUNT(root),L"Anthem_1.0.0.64_x64__8wekyb3d8bbwe\\Mount\\mediapc\\cars\\"))return;
 unsigned len=0;while(root[len]){pattern[len]=root[len];len++;}pattern[len]=0;
 if(!append_path(pattern,ARRAY_COUNT(pattern),L"*.fpsteering"))return;
 static WIN32_FIND_DATAW found;HANDLE search=FindFirstFileW(pattern,&found);if(search==INVALID_HANDLE_VALUE)return;
 unsigned scanned=0;
 do {
  if(++scanned>8192)break;
  if((found.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT))||found.cFileName[0]==L'.')continue;
  static wchar_t path[1024];memory_copy(path,root,(len+1)*sizeof(wchar_t));
  if(!append_path(path,ARRAY_COUNT(path),found.cFileName))continue;
  HANDLE file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(file==INVALID_HANDLE_VALUE)continue;
  static FpSteeringMap data;
  LARGE_INTEGER size;DWORD got=0;
  int valid=GetFileSizeEx(file,&size)&&size.QuadPart>=28&&size.QuadPart<=(LONGLONG)sizeof(data)&&ReadFile(file,&data,sizeof(data),&got,NULL)&&got==(DWORD)size.QuadPart;
  CloseHandle(file);
  if(!valid||!fp_map_valid(&data,got)||row_count+data.count>ARRAY_COUNT(rows))continue;
  if(valid){memory_copy(rows+row_count,data.records,data.count*sizeof(FpSteering));row_count+=data.count;}
 }while(FindNextFileW(search,&found));FindClose(search);
 log_append(row_count?"FORZAPORT STEERING: source selection maps loaded; experimental limits only, no rear-steer emulation.\r\n":"FORZAPORT STEERING: no valid maps; native steering unchanged.\r\n");
}
static BOOL CALLBACK load_once(PINIT_ONCE once,PVOID parameter,PVOID *context) {
 (void)once;(void)parameter;(void)context;load_profiles();return TRUE;
}
static int column(void *row,const FpString *name) {
 void *vt=NULL;uintptr_t method=0;
 if(!memory_read_pointer(row,&vt)||!memory_read((unsigned char *)vt+0xa0,&method,sizeof(method))||method<(uintptr_t)image+0x1000||method>=(uintptr_t)image+0x1dcc000)return -1;
 return ((int (*)(void *,unsigned,const FpString *,int))method)(row,0,name,-1);
}
static void apply(void *pointer,FpSteering selected,int valid) {
 float before[2];
 if(valid&&memory_read(pointer,before,sizeof(before))&&before[0]>0&&before[0]<=90&&before[1]>0&&before[1]<=90&&memory_is_writable(pointer,sizeof(before))){
  float values[2]={selected.maximum,selected.filtered};memory_copy(pointer,values,sizeof(values));
 }
}
static void suspension(void *output,void **part,void **database) {
 static const FpString id={.storage="Id",.length=2,.capacity=15},car={.storage="Ordinal",.length=7,.capacity=15};
 void *row=NULL;int pid=-1,cid=-1;
 if(part&&memory_read_pointer(part,&row)){pid=column(row,&id);cid=column(row,&car);}
 ((void (*)(void *,void **,void **))(image+0x10613f0))(output,part,database);
 FpSteering selected={0};int valid=fp_lookup(rows,row_count,cid,pid,&selected);
 void *definition=(unsigned char *)output-0x324;
 AcquireSRWLockExclusive(&lock);unsigned slot=64;
 for(unsigned i=0;i<64;i++)if(definitions[i].address==definition){slot=i;break;}
 if(slot==64)slot=next_definition++%64;
 definitions[slot]=(FpObject){.address=definition,.selection=selected,.valid=valid};ReleaseSRWLockExclusive(&lock);
 apply((unsigned char *)definition+0x5c,selected,valid);
}
static void initialized(void *output,const void *definition) {
 ((void (*)(void *,const void *))(image+0x12e0a50))(output,definition);
 FpObject record={.address=output,.definition=(void *)definition};
 AcquireSRWLockExclusive(&lock);
 for(unsigned i=0;i<64;i++)if(definitions[i].address==definition){record.selection=definitions[i].selection;record.valid=definitions[i].valid;break;}
 unsigned slot=64;for(unsigned i=0;i<64;i++)if(objects[i].address==output){slot=i;break;}
 if(slot==64)slot=next_object++%64;objects[slot]=record;ReleaseSRWLockExclusive(&lock);
 apply((unsigned char *)output+0x385c,record.selection,record.valid);
}
static void updated(void *object,float step) {
 FpObject record={0};AcquireSRWLockShared(&lock);
 for(unsigned i=0;i<64;i++)if(objects[i].address==object){record=objects[i];record.valid=0;for(unsigned j=0;j<64;j++)if(definitions[j].address==record.definition){if(definitions[j].selection.car==record.selection.car){record.selection=definitions[j].selection;record.valid=definitions[j].valid;}break;}break;}
 ReleaseSRWLockShared(&lock);
 apply((unsigned char *)object+0x385c,record.selection,record.valid);
 ((void (*)(void *,float))(image+0x12f39d0))(object,step);
}
PatchDefinition fp_steering_patches[7];
static unsigned char thunks[3][12],calls[4][5];
static const unsigned char padding[12]={0xcc,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc};
static const unsigned char original[4][5]={{0xe8,0x45,0x9c,0,0},{0xe8,0x1c,0xf9,0xff,0xff},{0xe8,0x0a,0xf9,0xff,0xff},{0xe8,0x63,0x04,0x02,0}};
static const unsigned char *accepted[7][2];
void fp_steering_prepare(unsigned char *base) {
 image=base;InitOnceExecuteOnce(&profiles_once,load_once,NULL,NULL);
 const unsigned rvas[3]={0x1061804,0x12e12b2,0x12f3c24};
 const uintptr_t callbacks[3]={(uintptr_t)suspension,(uintptr_t)initialized,(uintptr_t)updated};
 const unsigned char jump[12]={0x48,0xb8,0,0,0,0,0,0,0,0,0xff,0xe0};
 for(unsigned i=0;i<3;i++){memory_copy(thunks[i],jump,12);memory_copy(thunks[i]+2,&callbacks[i],8);accepted[i][0]=padding;accepted[i][1]=thunks[i];fp_steering_patches[i]=(PatchDefinition){rvas[i],0,12,GROUP_AERO_TUNING,"forzaport_steering_thunk",padding,thunks[i],thunks[i],accepted[i],2};}
 const unsigned sites[4]={0x10577a6,0x12e112f,0x12e1141,0x12d3568},targets[4]={0,1,1,2};
 for(unsigned i=0;i<4;i++){int32_t delta=(int32_t)(rvas[targets[i]]-sites[i]-5);calls[i][0]=0xe8;memory_copy(calls[i]+1,&delta,4);accepted[i+3][0]=original[i];accepted[i+3][1]=calls[i];fp_steering_patches[i+3]=(PatchDefinition){sites[i],0,5,GROUP_AERO_TUNING,"forzaport_steering_selection",original[i],calls[i],calls[i],accepted[i+3],2};}
}
