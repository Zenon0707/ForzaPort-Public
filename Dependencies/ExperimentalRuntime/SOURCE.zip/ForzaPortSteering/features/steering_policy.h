/* ForzaPort generic steering experiment; GPL-3.0-or-later. */
#ifndef FP_STEERING_POLICY_H
#define FP_STEERING_POLICY_H
#include <stdint.h>
typedef struct { int32_t car,part; float maximum,filtered; } FpSteering;
typedef struct { char magic[8]; uint32_t count; FpSteering records[64]; } FpSteeringMap;
_Static_assert(sizeof(FpSteering)==16,"Steering wire record");
static int fp_valid(FpSteering r) {
 return r.car>0 && r.part>0 && r.maximum>0 && r.maximum<=90 && r.filtered>0 && r.filtered<=90;
}
static int fp_lookup(const FpSteering *rows,unsigned count,int car,int part,FpSteering *out) {
 unsigned matches=0;
 for(unsigned i=0;i<count;i++)if(rows[i].car==car && rows[i].part==part){*out=rows[i];matches++;}
 return matches==1 && fp_valid(*out);
}
static int fp_map_valid(const FpSteeringMap *map,unsigned bytes) {
 const char magic[8]={'F','P','S','T','E','E','R','1'};
 if(bytes<28||!map->count||map->count>64||bytes!=12+map->count*16)return 0;
 for(unsigned i=0;i<8;i++)if(map->magic[i]!=magic[i])return 0;
 for(unsigned i=0;i<map->count;i++){
  if(!fp_valid(map->records[i]))return 0;
  for(unsigned j=0;j<i;j++)if(map->records[i].car==map->records[j].car&&map->records[i].part==map->records[j].part)return 0;
 }
 return 1;
}
#endif
