ForzaPort optional generic steering overlay. GPL-3.0-or-later. No anti-lag, vehicle-specific IDs or rear-wheel physics hooks. Runtime acceptance unverified.
